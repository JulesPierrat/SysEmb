#ifndef FB_H
#define FB_H

#include "fa.h"

void fb();

#endif

