#include "fb.h"
#include <stdio.h>

void fb()
{
	printf("B!\n");
}
