#include "fa.h"
#include <stdio.h>

void fa()
{
	printf("A!\n");
}
