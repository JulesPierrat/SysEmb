#include "fa.h"
#include "fb.h"

int main()
{
	fa();
	fb();
	return 0;
}
