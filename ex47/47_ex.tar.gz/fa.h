#ifndef FA_H
#define FA_H

#include "fb.h"

void fa();

#endif

